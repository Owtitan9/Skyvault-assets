# SkyVault Coin Metadata

This repository hosts token metadata and assets for the SkyVault Coin ($SKYV).